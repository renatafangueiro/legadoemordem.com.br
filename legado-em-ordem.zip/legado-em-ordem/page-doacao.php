<!doctype html>
<!-- Legado em Ordem · página doação · gerada a partir da página inicial · 2026-11-08 -->
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>ITCMD na doação e na extinção de usufruto no Paraná — Legado em Ordem</title>
<meta name="description" content="Fazemos a declaração do ITCMD da doação de imóvel ou dinheiro, com reserva de usufruto, e da extinção do usufruto no Paraná. A partir de R$ 347, resposta em até 2h úteis.">
<link rel="canonical" href="https://legadoemordem.com.br/doacao/">
<meta property="og:title" content="ITCMD na doação e na extinção de usufruto no Paraná — Legado em Ordem">
<meta property="og:description" content="Fazemos a declaração do ITCMD da doação de imóvel ou dinheiro, com reserva de usufruto, e da extinção do usufruto no Paraná. A partir de R$ 347, resposta em até 2h úteis.">
<meta name="theme-color" content="#F5F1E5">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo lo_t('favicon-32.png'); ?>">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo lo_t('apple-touch-icon.png'); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,600;0,700;1,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo lo_t('estilo.css'); ?>">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="nav" id="nav"><div class="wrap navin">
  <a class="marca" href="<?php echo lo_u(''); ?>" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem · ITCMD &amp; Patrimônio" width="480" height="187"></a>
  <nav class="links" aria-label="Menu principal">
    <a class="link" href="<?php echo lo_u('inventario/'); ?>">Inventário</a><a class="link" href="<?php echo lo_u('doacao/'); ?>" aria-current="true">Doação</a><a class="link" href="<?php echo lo_u('divorcio/'); ?>">Divórcio</a><a class="link" href="#perguntas">Perguntas</a>
  </nav>
  <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20uma%20doa%C3%A7%C3%A3o." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  <details class="menu-m"><summary aria-label="Abrir menu"><span></span></summary>
    <nav aria-label="Menu"><a href="<?php echo lo_u(''); ?>">Início</a><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a><a href="#perguntas">Perguntas</a></nav>
  </details>
</div></header>

<main id="inicio">
<section class="hero"><div class="wrap"><div class="stage topo">
  <p class="trilha rv"><a href="<?php echo lo_u(''); ?>">Início</a> · ITCMD na doação</p>
  <p class="kicker rv">Doação e extinção de usufruto · Paraná</p>
  <h1 class="rv">Fazemos a declaração do ITCMD da sua <em>doação</em></h1>
  <p class="lede rv">Doação de imóvel, de dinheiro ou de outros bens, com ou sem reserva de usufruto, e a extinção do usufruto anos depois. Você envia os documentos e nós cuidamos da declaração, à distância, em qualquer cidade do Paraná.</p>
  <ul class="selos rv"><li>100% online</li><li>Todo o Paraná</li><li>Resposta em até 2h úteis</li></ul>
  <p class="preco rv">Assessoria a partir de <b>R$&nbsp;347</b></p>
  <div class="acoes rv">
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20uma%20doa%C3%A7%C3%A3o." target="_blank" rel="noopener" data-whatsapp>Pedir orçamento pelo WhatsApp</a>
  </div>
  <p class="micro rv">Resposta em até 2 horas úteis · sem compromisso</p>
</div></div></section>

<section class="sec curta" id="por-que"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Se a declaração é gratuita, por que contratar?</p><h2 class="h2">Na doação, o imposto vem antes da escritura</h2></div>
    <p class="lede">Sem o ITCMD pago, o cartório não lavra a escritura de doação. Um erro na declaração atrasa tudo ou faz você pagar mais.</p>
  </div>
  <ul class="itc-base">
    <li class="rv"><h3>Valor do imóvel</h3><p>O imóvel não pode ser declarado abaixo da referência da prefeitura ou, no rural, da tabela do estado. Errar para menos gera <b>cobrança da diferença com multa e juros</b>; errar para mais é imposto pago à toa.</p></li>
    <li class="rv foco"><h3>Reserva de usufruto</h3><p>Quando os pais doam e ficam com o usufruto, a declaração precisa tratar a doação e o usufruto do jeito que a lei do Paraná pede. <b>E o fim do usufruto, anos depois, também exige providências.</b></p></li>
    <li class="rv"><h3>Prazo das certidões</h3><p>As certidões que o cartório pede têm validade curta. <b>Declaração devolvida para correção</b> pode fazer você tirar tudo de novo.</p></li>
  </ul>
</div></section>

<section class="sec curta itc" id="quando"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Quando o ITCMD aparece</p><h2 class="h2">Doação paga imposto, mesmo em família</h2></div>
    <p class="lede">No Paraná, a alíquota é de 4% do valor dos bens doados (Lei estadual 18.573/2015, art. 22).</p>
  </div>
  <ul class="itc-casos rv">
    <li><h4>Doação de imóvel</h4><p>Casa, apartamento, terreno ou imóvel rural. Se o imóvel fica no Paraná, o imposto é do Paraná, mesmo que doador ou donatário morem em outro estado.</p></li>
    <li><h4>Doação de pais para filhos</h4><p>O adiantamento de herança também paga o imposto, normalmente na mesma escritura da doação.</p></li>
    <li><h4>Doação com reserva de usufruto</h4><p>Os pais passam o imóvel aos filhos e continuam morando nele ou recebendo o aluguel até o fim da vida.</p></li>
    <li><h4>Extinção de usufruto</h4><p>Pelo falecimento ou pela renúncia de quem tinha o usufruto, o dono passa a ter a propriedade completa.</p></li>
    <li><h4>Doação de dinheiro e outros bens</h4><p>Dinheiro, aplicações, veículos, quotas e ações. Nos bens móveis, o imposto é do estado onde mora quem doa.</p></li>
    <li><h4>Doação com pagamento?</h4><p>Se quem recebe paga alguma coisa em troca, pode não ser doação: aí o imposto costuma ser o ITBI, da prefeitura.</p></li>
  </ul>
</div></section>

<section class="sec curta" id="usufruto"><div class="wrap">
  <div class="escuro rv">
    <div>
      <p class="kicker">Extinção de usufruto</p>
      <h2 class="h2">O usufruto acabou? A matrícula ainda não sabe</h2>
      <p class="lede">Com o falecimento ou a renúncia de quem tinha o usufruto, é preciso resolver o ITCMD na Receita Estadual e cancelar o usufruto na matrícula do imóvel. Muitas famílias só descobrem isso na hora de vender.</p>
    </div>
    <div class="em-breve">
      <p>Aqui não há nova escritura: a assessoria orienta os documentos, cuida da declaração e explica o pedido ao registro de imóveis.</p>
      <a class="btn ouro" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20uma%20extin%C3%A7%C3%A3o%20de%20usufruto." target="_blank" rel="noopener" data-whatsapp>Falar sobre extinção de usufruto</a>
    </div>
  </div>
</div></section>

<section class="sec curta" id="assessoria"><div class="wrap duas">
  <div class="rv">
    <p class="kicker">Documentos</p>
    <h2 class="h2">O que você vai precisar</h2>
    <p class="lede" style="margin-top:18px">Não tem tudo? A assessoria orienta onde pedir cada documento</p>
    <ol class="lista">
      <li>Documentos pessoais de quem doa e de quem recebe, com a certidão de nascimento ou de casamento</li>
      <li>Matrícula atualizada do imóvel</li>
      <li>Carnê do IPTU ou, no imóvel rural, CCIR, ITR e CAR</li>
      <li>Na extinção de usufruto: certidão de óbito ou escritura de renúncia de quem tinha o usufruto</li>
      <li>Nos outros bens: extratos, documento do veículo ou contrato social</li>
    </ol>
  </div>
  <aside class="cartao rv">
    <h3>Assessoria para a sua doação</h3>
    <p class="preco-grande"><small>a partir de</small>R$&nbsp;347</p>
    <ul>
      <li>Conferência dos documentos e do valor dos bens</li>
      <li>Declaração do ITCMD enviada à Receita Estadual</li>
      <li>Explicação das fases seguintes: pagamento, assinatura, registro e IPTU</li>
      <li>Orientações sobre o imposto de renda depois da escritura</li>
    </ul>
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20uma%20doa%C3%A7%C3%A3o." target="_blank" rel="noopener" data-whatsapp>Pedir orçamento pelo WhatsApp</a>
    <p class="micro" style="text-align:center">Resposta em até 2 horas úteis</p>
  </aside>
</div></section>

<section class="sec curta" id="caminho"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Como funciona</p><h2 class="h2">Da conversa ao registro, em 4 passos</h2></div>
  </div>
  <ol class="bento">
    <li class="rv"><div><h3>Você conta o caso</h3><p>Pelo WhatsApp: quem doa, quem recebe, qual bem e em que cidade. Em até 2 horas úteis você recebe o orçamento</p></div></li>
    <li class="rv"><div><h3>Envia os documentos</h3><p>A assessoria confere cada um e avisa o que falta ou está vencido</p></div></li>
    <li class="rv foco"><span class="pilula">Foco da assessoria</span><div><h3>Declaração do ITCMD</h3><p>Enviada online à Receita Estadual, com a base de cálculo e os documentos conferidos</p></div></li>
    <li class="rv"><div><h3>Escritura e registro</h3><p>Com o imposto pago, vocês assinam no cartório, pessoalmente ou por videoconferência, e explicamos o registro e o IPTU</p></div></li>
  </ol>
</div></section>

<section class="sec" id="depoimentos" style="padding-top:0"><div class="wrap"><div class="depo rv">
  <p class="kicker">Depoimentos</p>
  <h2 class="h2">O que dizem os clientes</h2>
  <ul class="depo-trilho" id="depo-trilho" aria-label="Depoimentos de clientes">
    <li><figure><blockquote><p>Conseguimos <mark>resolver tudo rápido</mark> e minha filha assinou à distância.</p></blockquote><figcaption>Cliente, dona de casa · contratou a assessoria para uma escritura de inventário</figcaption></figure></li>
    <li><figure><blockquote><p>Você é <mark>a melhor</mark>! Muito obrigado pelos teus serviços.</p></blockquote><figcaption>Cliente, advogado · contratou a assessoria para uma escritura de permuta</figcaption></figure></li>
    <li><figure><blockquote><p>Parabéns… você é <mark>super diligente e competente</mark>. Vou precisar agendar uma outra missão.</p></blockquote><figcaption>Cliente, advogado · contratou a assessoria para uma escritura de cessão de direitos hereditários</figcaption></figure></li>
  </ul>
  <div class="depo-pontos" id="depo-pontos"></div>
  <p class="micro">Mensagens reais recebidas pelo WhatsApp. Os nomes foram omitidos para preservar a privacidade dos clientes.</p>
</div></div></section>

<section class="sec" id="perguntas" style="padding-top:0"><div class="wrap faq-grid">
  <div class="rv"><p class="kicker">Dúvidas sobre doação</p><h2 class="h2">O que costumam nos perguntar</h2></div>
  <div class="perguntas rv">
    <details><summary>Doação de pais para filhos paga ITCMD?</summary><p>Sim. A doação de pais para filhos, inclusive como adiantamento de herança, paga o imposto normalmente, antes da assinatura da escritura.</p></details>
    <details><summary>Doação em dinheiro também paga?</summary><p>Sim. Dinheiro, aplicações e outros bens móveis também pagam ITCMD, ao estado onde mora quem doa.</p></details>
    <details><summary>O usufruto acabou. Preciso fazer alguma coisa?</summary><p>Sim. Com o falecimento ou a renúncia de quem tinha o usufruto, é preciso resolver o ITCMD na Receita Estadual e cancelar o usufruto na matrícula. Sem isso, o imóvel continua com o usufruto registrado e a venda fica travada.</p></details>
    <details><summary>Preciso ir presencialmente a algum lugar?</summary><p>A assessoria é toda à distância. A escritura pode ser assinada pessoalmente ou por videoconferência, nos cartórios que trabalham com o e-Notariado.</p></details>
    <details><summary>Quanto custa?</summary><p>A assessoria começa em R$&nbsp;347. O valor final depende do número de pessoas, da quantidade de bens e dos documentos que faltam. Conte o seu caso pelo WhatsApp e receba o orçamento em até 2 horas úteis.</p></details>
  </div>
</div></section>

<section class="sec" style="padding-top:0;padding-bottom:clamp(24px,3vw,40px)"><div class="wrap"><div class="stage cta rv">
  <h2 class="h2">Vai doar ou receber um imóvel? Comece pelo imposto.</h2>
  <p class="lede">Conte o caso e receba o orçamento em até 2 horas úteis.</p>
  <div class="acoes">
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20uma%20doa%C3%A7%C3%A3o." target="_blank" rel="noopener" data-whatsapp>Pedir orçamento pelo WhatsApp</a>
  </div>
  <div class="outros"><a class="btn sec" href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a><a class="btn sec" href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a></div>
</div></div></section>
</main>

<footer class="rodape"><div class="wrap">
  <div class="rod-topo quatro">
    <div>
      <a class="marca" href="<?php echo lo_u('#inicio'); ?>" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem" width="480" height="187"></a>
      <p class="rod-txt">Assessoria para declaração de ITCMD<br>Atendimento à distância, em todo o Paraná</p>
    </div>
    <div><h4>Casos</h4><ul><li><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a></li><li><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a></li><li><a href="<?php echo lo_u('doacao/#usufruto'); ?>">Extinção de usufruto</a></li><li><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a></li></ul></div>
    <div><h4>Navegação</h4><ul><li><a href="<?php echo lo_u('#itcmd'); ?>">O que é o ITCMD</a></li><li><a href="<?php echo lo_u('#caminho'); ?>">O caminho</a></li><li><a href="<?php echo lo_u('#assessoria'); ?>">A assessoria</a></li><li><a href="<?php echo lo_u('#perguntas'); ?>">Perguntas</a></li></ul></div>
    <div><h4>Contato</h4><ul><li><a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20uma%20doa%C3%A7%C3%A3o." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></li><li><button type="button" class="linkbtn" data-politica>Política de privacidade</button></li></ul></div>
  </div>
  <div class="rod-base"><span>© 2026 Legado em Ordem</span><button type="button" class="linkbtn" data-politica>Política de privacidade</button></div>
  <p class="rod-legal">Legado em Ordem · CNPJ 48.747.993/0001-96 · Paranaguá-PR<br>Empresa privada, sem vínculo com a Receita Estadual ou outros órgãos públicos.</p>
</div></footer>

<div class="fixo"><a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20uma%20doa%C3%A7%C3%A3o." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></div>

<dialog id="politica" aria-labelledby="pol-titulo"><div class="pol">
  <h2 id="pol-titulo">Política de privacidade</h2>
  <p>Como a Legado em Ordem trata os seus dados.</p>
  <h3>Responsável</h3><p>Legado em Ordem, CNPJ 48.747.993/0001-96, Paranaguá-PR.</p>
  <h3>Dados tratados</h3><p>As informações e os documentos que você nos envia ao entrar em contato pelo WhatsApp e dados de navegação coletados pela ferramenta de medição de anúncios do Google: com cookies, se você aceitá-los; sem cookies e sem identificar você, se você recusar ou não responder ao aviso (por exemplo, a página visitada e o clique no botão do WhatsApp).</p>
  <h3>Finalidade</h3><p>Responder ao seu contato, prestar o serviço contratado e medir o desempenho dos anúncios.</p>
  <h3>Base legal</h3><p>Procedimentos preliminares e execução de contrato (Lei 13.709/2018 (LGPD), art. 7º, V), para o atendimento e o serviço; consentimento (art. 7º, I), para os cookies de medição, que você pode recusar no aviso exibido no site; legítimo interesse (art. 7º, IX), para a medição sem cookies dos anúncios.</p>
  <h3>Compartilhamento</h3><p>Os dados não são vendidos nem cedidos para fins comerciais. Quando necessário ao serviço, são compartilhados com a Receita Estadual, o cartório e o registro de imóveis. A ferramenta de medição (Google) trata dados de navegação: com cookies, de quem os aceita; sem cookies, dos demais visitantes.</p>
  <h3>Prazo</h3><p>Os dados são mantidos pelo tempo necessário à finalidade ou ao cumprimento de obrigações legais.</p>
  <h3>Direitos do titular</h3>
  <ul><li>Confirmar se há tratamento e acessar os dados</li><li>Corrigir dados incompletos ou desatualizados</li><li>Pedir a exclusão dos dados, ressalvado o que a lei obriga a guardar</li><li>Revogar o consentimento dado aos cookies</li></ul>
  <p>Pedidos pelo WhatsApp <a href="https://wa.me/legado.em.ordem" target="_blank" rel="noopener">(41) 9 9153-1196</a>.</p>
  <p>Atualizada em 03/11/2026.</p>
  <form method="dialog"><button class="btn sec">Fechar</button></form>
</div></dialog>

<div class="cookies" id="cookies" role="dialog" aria-live="polite" aria-label="Aviso de cookies" hidden>
  <p>Usamos cookies para medir o desempenho dos nossos anúncios. Você pode aceitar ou recusar.</p>
  <div class="acoes-c">
    <button type="button" class="btn" data-cookies="aceito">Aceitar</button>
    <button type="button" class="btn sec" data-cookies="recusado">Recusar</button>
    <button type="button" class="linkbtn" data-politica>Política de privacidade</button>
  </div>
</div>



<script src="<?php echo lo_t('site.js'); ?>"></script>
<?php wp_footer(); ?>
</body>
</html>
