<?php
/* Legado em Ordem · funções do tema */
if (!defined('ABSPATH')) exit;

/* Endereço de um arquivo do tema (CSS, JS, imagens), com versão para renovar o cache. */
function lo_t($arquivo) {
  $url = get_template_directory_uri() . '/' . $arquivo;
  if (preg_match('/\.(css|js)$/', $arquivo)) $url .= '?v=' . wp_get_theme()->get('Version');
  return esc_url($url);
}
/* Endereço de uma página do site: lo_u('inventario/'), lo_u('#itcmd'). */
function lo_u($caminho = '') {
  return esc_url(home_url('/' . $caminho));
}

add_action('after_setup_theme', function () {
  add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script'));
  add_theme_support('post-thumbnails');
  add_theme_support('responsive-embeds');
});

/* Sem emojis do WordPress (o site não usa) */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

/* O tema já escreve o <title> de cada página */
add_filter('document_title_separator', function () { return '—'; });
