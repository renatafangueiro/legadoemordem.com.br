<!doctype html>
<!-- Legado em Ordem · página divórcio · gerada a partir da página inicial · 2026-11-08 -->
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>ITCMD no divórcio e na união estável no Paraná — Legado em Ordem</title>
<meta name="description" content="Fazemos a declaração do ITCMD no divórcio e no fim da união estável com partilha desigual, no Paraná. À distância, a partir de R$ 347, resposta em até 2h úteis.">
<link rel="canonical" href="https://legadoemordem.com.br/divorcio/">
<meta property="og:title" content="ITCMD no divórcio e na união estável no Paraná — Legado em Ordem">
<meta property="og:description" content="Fazemos a declaração do ITCMD no divórcio e no fim da união estável com partilha desigual, no Paraná. À distância, a partir de R$ 347, resposta em até 2h úteis.">
<meta name="theme-color" content="#F5F1E5">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo lo_t('favicon-32.png'); ?>">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo lo_t('apple-touch-icon.png'); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,600;0,700;1,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo lo_t('estilo.css'); ?>">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="nav" id="nav"><div class="wrap navin">
  <a class="marca" href="<?php echo lo_u(''); ?>" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem · ITCMD &amp; Patrimônio" width="480" height="187"></a>
  <nav class="links" aria-label="Menu principal">
    <a class="link" href="<?php echo lo_u('inventario/'); ?>">Inventário</a><a class="link" href="<?php echo lo_u('doacao/'); ?>">Doação</a><a class="link" href="<?php echo lo_u('divorcio/'); ?>" aria-current="true">Divórcio</a><a class="link" href="#perguntas">Perguntas</a>
  </nav>
  <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20um%20div%C3%B3rcio%20ou%20fim%20de%20uni%C3%A3o%20est%C3%A1vel." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  <details class="menu-m"><summary aria-label="Abrir menu"><span></span></summary>
    <nav aria-label="Menu"><a href="<?php echo lo_u(''); ?>">Início</a><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a><a href="#perguntas">Perguntas</a></nav>
  </details>
</div></header>

<main id="inicio">
<section class="hero"><div class="wrap"><div class="stage topo">
  <p class="trilha rv"><a href="<?php echo lo_u(''); ?>">Início</a> · ITCMD no divórcio</p>
  <p class="kicker rv">Divórcio, separação e fim da união estável · Paraná</p>
  <h1 class="rv">Fazemos a declaração do ITCMD do seu <em>divórcio</em></h1>
  <p class="lede rv">Divórcio, separação ou fim de união estável em que um fica com mais do que a sua metade dos bens. Você envia os documentos e nós cuidamos da declaração, à distância, em qualquer cidade do Paraná.</p>
  <ul class="selos rv"><li>100% online</li><li>Todo o Paraná</li><li>Resposta em até 2h úteis</li></ul>
  <p class="preco rv">Assessoria a partir de <b>R$&nbsp;347</b></p>
  <div class="acoes rv">
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20um%20div%C3%B3rcio%20ou%20fim%20de%20uni%C3%A3o%20est%C3%A1vel." target="_blank" rel="noopener" data-whatsapp>Pedir orçamento pelo WhatsApp</a>
  </div>
  <p class="micro rv">Resposta em até 2 horas úteis · sem compromisso</p>
</div></div></section>

<section class="sec curta" id="por-que"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Se a declaração é gratuita, por que contratar?</p><h2 class="h2">No divórcio, o primeiro passo é saber qual imposto pagar</h2></div>
    <p class="lede">A mesma divisão de bens pode gerar ITCMD, ITBI ou nenhum imposto. Errar o caminho atrasa a escritura e pode custar caro.</p>
  </div>
  <ul class="itc-base">
    <li class="rv"><h3>ITCMD ou ITBI?</h3><p>Se quem fica com mais compensa o outro em dinheiro, o imposto é o <b>ITBI, da prefeitura</b>. Se não compensa, a diferença é tratada como doação e paga <b>ITCMD, do estado</b>.</p></li>
    <li class="rv foco"><h3>Só sobre a diferença</h3><p>O imposto incide sobre o que passa da metade de cada um. <b>Esse cálculo depende do regime de bens</b> e do valor de cada bem da partilha.</p></li>
    <li class="rv"><h3>Valor dos bens</h3><p>Imóveis não podem ser declarados abaixo da referência da prefeitura ou, nos rurais, da tabela do estado. <b>Errar para menos gera cobrança com multa e juros.</b></p></li>
  </ul>
</div></section>

<section class="sec curta itc" id="quando"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Quando o ITCMD aparece</p><h2 class="h2">Partilha desigual é doação</h2></div>
    <p class="lede">No Paraná, a alíquota é de 4% sobre a parte recebida a mais (Lei estadual 18.573/2015, art. 22).</p>
  </div>
  <ul class="itc-casos rv">
    <li><h4>Partilha desigual, sem compensação</h4><p>Um fica com mais do que a sua metade e não paga a diferença ao outro: a parte a mais paga ITCMD.</p></li>
    <li><h4>Partilha meio a meio</h4><p>Se cada um fica exatamente com a sua metade, não há ITCMD sobre a partilha.</p></li>
    <li><h4>Compensação em dinheiro</h4><p>Se quem fica com mais paga a diferença ao outro, o imposto costuma ser o ITBI, da prefeitura.</p></li>
    <li><h4>Divórcio em cartório</h4><p>O imposto é pago antes da assinatura da escritura de divórcio ou de partilha.</p></li>
    <li><h4>Fim da união estável</h4><p>As mesmas regras valem na dissolução da união estável, em cartório ou na Justiça.</p></li>
    <li><h4>Imóvel no Paraná</h4><p>O imposto é do Paraná mesmo que o casal more em outro estado.</p></li>
  </ul>
</div></section>

<section class="sec curta" id="assessoria"><div class="wrap duas">
  <div class="rv">
    <p class="kicker">Documentos</p>
    <h2 class="h2">O que você vai precisar</h2>
    <p class="lede" style="margin-top:18px">Não tem tudo? A assessoria orienta onde pedir cada documento</p>
    <ol class="lista">
      <li>Certidão de casamento ou escritura de união estável, e o pacto antenupcial, se houver</li>
      <li>Documentos pessoais dos dois</li>
      <li>Matrícula atualizada e carnê do IPTU de cada imóvel ou, no rural, CCIR, ITR e CAR</li>
      <li>Documentos dos outros bens: veículos, aplicações, quotas</li>
      <li>A proposta de partilha: quem fica com o quê</li>
    </ol>
  </div>
  <aside class="cartao rv">
    <h3>Assessoria para o seu divórcio</h3>
    <p class="preco-grande"><small>a partir de</small>R$&nbsp;347</p>
    <ul>
      <li>Análise da partilha: se há ITCMD, ITBI ou nenhum imposto</li>
      <li>Cálculo da diferença e declaração do ITCMD</li>
      <li>Explicação das fases seguintes: pagamento, assinatura, registro e IPTU</li>
      <li>Orientações sobre o imposto de renda depois da escritura</li>
    </ul>
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20um%20div%C3%B3rcio%20ou%20fim%20de%20uni%C3%A3o%20est%C3%A1vel." target="_blank" rel="noopener" data-whatsapp>Pedir orçamento pelo WhatsApp</a>
    <p class="micro" style="text-align:center">Resposta em até 2 horas úteis</p>
  </aside>
</div></section>

<section class="sec curta" id="caminho"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Como funciona</p><h2 class="h2">Da conversa ao registro, em 4 passos</h2></div>
  </div>
  <ol class="bento">
    <li class="rv"><div><h3>Você conta o caso</h3><p>Pelo WhatsApp: quais bens, como ficará a divisão e em que cidade. Em até 2 horas úteis você recebe o orçamento</p></div></li>
    <li class="rv"><div><h3>Envia os documentos</h3><p>A assessoria confere cada um e avisa o que falta ou está vencido</p></div></li>
    <li class="rv foco"><span class="pilula">Foco da assessoria</span><div><h3>Declaração do ITCMD</h3><p>Enviada online à Receita Estadual, com a diferença calculada e os documentos conferidos</p></div></li>
    <li class="rv"><div><h3>Escritura e registro</h3><p>Com o imposto pago, vocês assinam, pessoalmente ou por videoconferência, e explicamos o registro e o IPTU</p></div></li>
  </ol>
</div></section>

<section class="sec" id="depoimentos" style="padding-top:0"><div class="wrap"><div class="depo rv">
  <p class="kicker">Depoimentos</p>
  <h2 class="h2">O que dizem os clientes</h2>
  <ul class="depo-trilho" id="depo-trilho" aria-label="Depoimentos de clientes">
    <li><figure><blockquote><p>Conseguimos <mark>resolver tudo rápido</mark> e minha filha assinou à distância.</p></blockquote><figcaption>Cliente, dona de casa · contratou a assessoria para uma escritura de inventário</figcaption></figure></li>
    <li><figure><blockquote><p>Você é <mark>a melhor</mark>! Muito obrigado pelos teus serviços.</p></blockquote><figcaption>Cliente, advogado · contratou a assessoria para uma escritura de permuta</figcaption></figure></li>
    <li><figure><blockquote><p>Parabéns… você é <mark>super diligente e competente</mark>. Vou precisar agendar uma outra missão.</p></blockquote><figcaption>Cliente, advogado · contratou a assessoria para uma escritura de cessão de direitos hereditários</figcaption></figure></li>
  </ul>
  <div class="depo-pontos" id="depo-pontos"></div>
  <p class="micro">Mensagens reais recebidas pelo WhatsApp. Os nomes foram omitidos para preservar a privacidade dos clientes.</p>
</div></div></section>

<section class="sec" id="perguntas" style="padding-top:0"><div class="wrap faq-grid">
  <div class="rv"><p class="kicker">Dúvidas sobre divórcio</p><h2 class="h2">O que costumam nos perguntar</h2></div>
  <div class="perguntas rv">
    <details><summary>A partilha foi meio a meio. Tem ITCMD?</summary><p>Não. Se cada um fica exatamente com a sua metade, não há ITCMD sobre a partilha.</p></details>
    <details><summary>Vocês fazem o divórcio?</summary><p>A assessoria cuida da declaração do ITCMD e explica cada fase. O divórcio é feito pelo advogado do casal, no cartório ou na Justiça.</p></details>
    <details><summary>Vale também para união estável?</summary><p>Sim. Na dissolução da união estável, a partilha desigual sem compensação também paga ITCMD.</p></details>
    <details><summary>Preciso ir presencialmente a algum lugar?</summary><p>A assessoria é toda à distância. A escritura pode ser assinada pessoalmente ou por videoconferência, nos cartórios que trabalham com o e-Notariado.</p></details>
    <details><summary>Quanto custa?</summary><p>A assessoria começa em R$&nbsp;347. O valor final depende da quantidade de bens e dos documentos que faltam. Conte o seu caso pelo WhatsApp e receba o orçamento em até 2 horas úteis.</p></details>
  </div>
</div></section>

<section class="sec" style="padding-top:0;padding-bottom:clamp(24px,3vw,40px)"><div class="wrap"><div class="stage cta rv">
  <h2 class="h2">Vai dividir os bens? Veja antes qual imposto se aplica.</h2>
  <p class="lede">Conte o caso e receba o orçamento em até 2 horas úteis.</p>
  <div class="acoes">
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20um%20div%C3%B3rcio%20ou%20fim%20de%20uni%C3%A3o%20est%C3%A1vel." target="_blank" rel="noopener" data-whatsapp>Pedir orçamento pelo WhatsApp</a>
  </div>
  <div class="outros"><a class="btn sec" href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a><a class="btn sec" href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a></div>
</div></div></section>
</main>

<footer class="rodape"><div class="wrap">
  <div class="rod-topo quatro">
    <div>
      <a class="marca" href="<?php echo lo_u('#inicio'); ?>" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem" width="480" height="187"></a>
      <p class="rod-txt">Assessoria para declaração de ITCMD<br>Atendimento à distância, em todo o Paraná</p>
    </div>
    <div><h4>Casos</h4><ul><li><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a></li><li><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a></li><li><a href="<?php echo lo_u('doacao/#usufruto'); ?>">Extinção de usufruto</a></li><li><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a></li></ul></div>
    <div><h4>Navegação</h4><ul><li><a href="<?php echo lo_u('#itcmd'); ?>">O que é o ITCMD</a></li><li><a href="<?php echo lo_u('#caminho'); ?>">O caminho</a></li><li><a href="<?php echo lo_u('#assessoria'); ?>">A assessoria</a></li><li><a href="<?php echo lo_u('#perguntas'); ?>">Perguntas</a></li></ul></div>
    <div><h4>Contato</h4><ul><li><a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20um%20div%C3%B3rcio%20ou%20fim%20de%20uni%C3%A3o%20est%C3%A1vel." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></li><li><button type="button" class="linkbtn" data-politica>Política de privacidade</button></li></ul></div>
  </div>
  <div class="rod-base"><span>© 2026 Legado em Ordem</span><button type="button" class="linkbtn" data-politica>Política de privacidade</button></div>
  <p class="rod-legal">Legado em Ordem · CNPJ 48.747.993/0001-96 · Paranaguá-PR<br>Empresa privada, sem vínculo com a Receita Estadual ou outros órgãos públicos.</p>
</div></footer>

<div class="fixo"><a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD%20de%20um%20div%C3%B3rcio%20ou%20fim%20de%20uni%C3%A3o%20est%C3%A1vel." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></div>

<dialog id="politica" aria-labelledby="pol-titulo"><div class="pol">
  <h2 id="pol-titulo">Política de privacidade</h2>
  <p>Como a Legado em Ordem trata os seus dados.</p>
  <h3>Responsável</h3><p>Legado em Ordem, CNPJ 48.747.993/0001-96, Paranaguá-PR.</p>
  <h3>Dados tratados</h3><p>As informações e os documentos que você nos envia ao entrar em contato pelo WhatsApp e dados de navegação coletados pela ferramenta de medição de anúncios do Google: com cookies, se você aceitá-los; sem cookies e sem identificar você, se você recusar ou não responder ao aviso (por exemplo, a página visitada e o clique no botão do WhatsApp).</p>
  <h3>Finalidade</h3><p>Responder ao seu contato, prestar o serviço contratado e medir o desempenho dos anúncios.</p>
  <h3>Base legal</h3><p>Procedimentos preliminares e execução de contrato (Lei 13.709/2018 (LGPD), art. 7º, V), para o atendimento e o serviço; consentimento (art. 7º, I), para os cookies de medição, que você pode recusar no aviso exibido no site; legítimo interesse (art. 7º, IX), para a medição sem cookies dos anúncios.</p>
  <h3>Compartilhamento</h3><p>Os dados não são vendidos nem cedidos para fins comerciais. Quando necessário ao serviço, são compartilhados com a Receita Estadual, o cartório e o registro de imóveis. A ferramenta de medição (Google) trata dados de navegação: com cookies, de quem os aceita; sem cookies, dos demais visitantes.</p>
  <h3>Prazo</h3><p>Os dados são mantidos pelo tempo necessário à finalidade ou ao cumprimento de obrigações legais.</p>
  <h3>Direitos do titular</h3>
  <ul><li>Confirmar se há tratamento e acessar os dados</li><li>Corrigir dados incompletos ou desatualizados</li><li>Pedir a exclusão dos dados, ressalvado o que a lei obriga a guardar</li><li>Revogar o consentimento dado aos cookies</li></ul>
  <p>Pedidos pelo WhatsApp <a href="https://wa.me/legado.em.ordem" target="_blank" rel="noopener">(41) 9 9153-1196</a>.</p>
  <p>Atualizada em 03/11/2026.</p>
  <form method="dialog"><button class="btn sec">Fechar</button></form>
</div></dialog>

<div class="cookies" id="cookies" role="dialog" aria-live="polite" aria-label="Aviso de cookies" hidden>
  <p>Usamos cookies para medir o desempenho dos nossos anúncios. Você pode aceitar ou recusar.</p>
  <div class="acoes-c">
    <button type="button" class="btn" data-cookies="aceito">Aceitar</button>
    <button type="button" class="btn sec" data-cookies="recusado">Recusar</button>
    <button type="button" class="linkbtn" data-politica>Política de privacidade</button>
  </div>
</div>



<script src="<?php echo lo_t('site.js'); ?>"></script>
<?php wp_footer(); ?>
</body>
</html>
