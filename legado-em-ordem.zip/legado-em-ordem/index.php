<!doctype html>
<!-- Legado em Ordem · modelo genérico de página -->
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?php echo esc_html(wp_get_document_title()); ?></title>
<meta name="theme-color" content="#F5F1E5">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo lo_t('favicon-32.png'); ?>">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo lo_t('apple-touch-icon.png'); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,600;0,700;1,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo lo_t('estilo.css'); ?>">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="nav" id="nav"><div class="wrap navin">
  <a class="marca" href="<?php echo lo_u(''); ?>" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem · ITCMD &amp; Patrimônio" width="480" height="187"></a>
  <nav class="links" aria-label="Menu principal">
    <a class="link" href="<?php echo lo_u('inventario/'); ?>">Inventário</a><a class="link" href="<?php echo lo_u('doacao/'); ?>">Doação</a><a class="link" href="<?php echo lo_u('divorcio/'); ?>">Divórcio</a><a class="link" href="<?php echo lo_u('#perguntas'); ?>">Perguntas</a>
  </nav>
  <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  <details class="menu-m"><summary aria-label="Abrir menu"><span></span></summary>
    <nav aria-label="Menu"><a href="<?php echo lo_u(''); ?>">Início</a><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a><a href="<?php echo lo_u('#perguntas'); ?>">Perguntas</a></nav>
  </details>
</div></header>

<main id="inicio">
<?php while (have_posts()) : the_post(); ?>
<section class="hero"><div class="wrap"><div class="stage topo">
  <p class="trilha rv"><a href="<?php echo lo_u(); ?>">Início</a> · <?php the_title(); ?></p>
  <h1 class="rv"><?php the_title(); ?></h1>
</div></div></section>
<section class="sec curta"><div class="wrap"><div class="prosa">
  <?php the_content(); ?>
</div></div></section>
<?php endwhile; ?>
</main>

<footer class="rodape"><div class="wrap">
  <div class="rod-topo quatro">
    <div>
      <a class="marca" href="<?php echo lo_u('#inicio'); ?>" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem" width="480" height="187"></a>
      <p class="rod-txt">Assessoria para declaração de ITCMD<br>Atendimento à distância, em todo o Paraná</p>
    </div>
    <div><h4>Casos</h4><ul><li><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a></li><li><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a></li><li><a href="<?php echo lo_u('doacao/#usufruto'); ?>">Extinção de usufruto</a></li><li><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a></li></ul></div>
    <div><h4>Navegação</h4><ul><li><a href="<?php echo lo_u('#itcmd'); ?>">O que é o ITCMD</a></li><li><a href="<?php echo lo_u('#caminho'); ?>">O caminho</a></li><li><a href="<?php echo lo_u('#assessoria'); ?>">A assessoria</a></li><li><a href="<?php echo lo_u('#perguntas'); ?>">Perguntas</a></li></ul></div>
    <div><h4>Contato</h4><ul><li><a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></li><li><button type="button" class="linkbtn" data-politica>Política de privacidade</button></li></ul></div>
  </div>
  <div class="rod-base"><span>© 2026 Legado em Ordem</span><button type="button" class="linkbtn" data-politica>Política de privacidade</button></div>
  <p class="rod-legal">Legado em Ordem · CNPJ 48.747.993/0001-96 · Paranaguá-PR<br>Empresa privada, sem vínculo com a Receita Estadual ou outros órgãos públicos.</p>
</div></footer>

<div class="fixo"><a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></div>

<dialog id="politica" aria-labelledby="pol-titulo"><div class="pol">
  <h2 id="pol-titulo">Política de privacidade</h2>
  <p>Como a Legado em Ordem trata os seus dados.</p>
  <h3>Responsável</h3><p>Legado em Ordem, CNPJ 48.747.993/0001-96, Paranaguá-PR.</p>
  <h3>Dados tratados</h3><p>As informações e os documentos que você nos envia ao entrar em contato pelo WhatsApp e dados de navegação coletados pela ferramenta de medição de anúncios do Google: com cookies, se você aceitá-los; sem cookies e sem identificar você, se você recusar ou não responder ao aviso (por exemplo, a página visitada e o clique no botão do WhatsApp).</p>
  <h3>Finalidade</h3><p>Responder ao seu contato, prestar o serviço contratado e medir o desempenho dos anúncios.</p>
  <h3>Base legal</h3><p>Procedimentos preliminares e execução de contrato (Lei 13.709/2018 (LGPD), art. 7º, V), para o atendimento e o serviço; consentimento (art. 7º, I), para os cookies de medição, que você pode recusar no aviso exibido no site; legítimo interesse (art. 7º, IX), para a medição sem cookies dos anúncios.</p>
  <h3>Compartilhamento</h3><p>Os dados não são vendidos nem cedidos para fins comerciais. Quando necessário ao serviço, são compartilhados com a Receita Estadual, o cartório e o registro de imóveis. A ferramenta de medição (Google) trata dados de navegação: com cookies, de quem os aceita; sem cookies, dos demais visitantes.</p>
  <h3>Prazo</h3><p>Os dados são mantidos pelo tempo necessário à finalidade ou ao cumprimento de obrigações legais.</p>
  <h3>Direitos do titular</h3>
  <ul><li>Confirmar se há tratamento e acessar os dados</li><li>Corrigir dados incompletos ou desatualizados</li><li>Pedir a exclusão dos dados, ressalvado o que a lei obriga a guardar</li><li>Revogar o consentimento dado aos cookies</li></ul>
  <p>Pedidos pelo WhatsApp <a href="https://wa.me/legado.em.ordem" target="_blank" rel="noopener">(41) 9 9153-1196</a>.</p>
  <p>Atualizada em 03/11/2026.</p>
  <form method="dialog"><button class="btn sec">Fechar</button></form>
</div></dialog>

<div class="cookies" id="cookies" role="dialog" aria-live="polite" aria-label="Aviso de cookies" hidden>
  <p>Usamos cookies para medir o desempenho dos nossos anúncios. Você pode aceitar ou recusar.</p>
  <div class="acoes-c">
    <button type="button" class="btn" data-cookies="aceito">Aceitar</button>
    <button type="button" class="btn sec" data-cookies="recusado">Recusar</button>
    <button type="button" class="linkbtn" data-politica>Política de privacidade</button>
  </div>
</div>



<script src="<?php echo lo_t('site.js'); ?>"></script>
<?php wp_footer(); ?>
</body>
</html>
