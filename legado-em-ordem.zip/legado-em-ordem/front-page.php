<!doctype html>
<!-- Legado em Ordem · site v4 · design system inspirado em "Lilac Meadow / rose", vestido com a marca · 2026-10-26 -->
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Legado em Ordem — Declaração de ITCMD no Paraná</title>
<meta name="description" content="Fazemos a sua declaração de ITCMD no Paraná: inventário, doação, extinção de usufruto e divórcio, à distância. Assessoria a partir de R$ 347, resposta em até 2h úteis.">
<link rel="canonical" href="https://legadoemordem.com.br/">
<meta property="og:title" content="Legado em Ordem — ITCMD & Patrimônio">
<meta property="og:description" content="Assessoria para declaração de ITCMD no Paraná.">
<meta name="theme-color" content="#F5F1E5">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo lo_t('favicon-32.png'); ?>">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo lo_t('apple-touch-icon.png'); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,600;0,700;1,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo lo_t('estilo.css'); ?>">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="nav" id="nav"><div class="wrap navin">
  <a class="marca" href="#inicio" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem · ITCMD &amp; Patrimônio" width="480" height="187"></a>
  <nav class="links" aria-label="Menu principal">
    <a class="link" href="<?php echo lo_u('inventario/'); ?>">Inventário</a><a class="link" href="<?php echo lo_u('doacao/'); ?>">Doação</a><a class="link" href="<?php echo lo_u('divorcio/'); ?>">Divórcio</a><a class="link" href="#itcmd">O ITCMD</a><a class="link" href="#perguntas">Perguntas</a>
  </nav>
  <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  <details class="menu-m"><summary aria-label="Abrir menu"><span></span></summary>
    <nav aria-label="Menu"><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a><a href="#itcmd">O que é o ITCMD</a><a href="#caminho">O caminho</a><a href="#perguntas">Perguntas</a></nav>
  </details>
</div></header>

<main id="inicio">
<section class="hero"><div class="wrap"><div class="stage topo">
  <p class="kicker rv">Herança, doação, divórcio e extinção de usufruto · Paraná</p>
  <h1 class="rv">Fazemos a sua declaração de ITCMD, <em>do início ao fim</em></h1>
  <p class="lede rv">Você envia os documentos e nós cuidamos do resto: conferimos, fazemos a declaração e explicamos cada fase até o registro do imóvel. Tudo à distância, em qualquer cidade do Paraná.</p>
  <ul class="selos rv"><li>100% online</li><li>Todo o Paraná</li><li>Resposta em até 2h úteis</li></ul>
  <p class="preco rv">Assessoria a partir de <b>R$&nbsp;347</b></p>
  <div class="acoes rv">
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  </div>
  <p class="micro rv">Resposta em até 2 horas úteis · sem compromisso</p>
</div></div></section>

<section class="sec curta" id="casos"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Qual é o seu caso?</p><h2 class="h2">Escolha a situação e veja como funciona</h2></div>
    <p class="lede">Cada caso tem as suas regras, os seus documentos e os seus cuidados com o imposto.</p>
  </div>
  <ul class="casos">
    <li class="rv"><a href="<?php echo lo_u('inventario/'); ?>"><h3>Inventário</h3><p>Herança, no cartório ou na Justiça, sobrepartilha, renúncia e cessão de herança</p><span class="ir">ITCMD no inventário</span></a></li>
    <li class="rv"><a href="<?php echo lo_u('doacao/'); ?>"><h3>Doação e usufruto</h3><p>Doação de imóvel ou de dinheiro, com ou sem reserva de usufruto, e extinção do usufruto</p><span class="ir">ITCMD na doação</span></a></li>
    <li class="rv"><a href="<?php echo lo_u('divorcio/'); ?>"><h3>Divórcio e união estável</h3><p>Partilha em que um fica com mais do que a sua metade dos bens</p><span class="ir">ITCMD no divórcio</span></a></li>
    <li class="rv outro"><a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp><h3>Outro caso</h3><p>Não sabe se precisa pagar ITCMD ou em qual caso se encaixa? Conte pelo WhatsApp</p><span class="ir">Falar pelo WhatsApp</span></a></li>
  </ul>
</div></section>

<section class="sec curta" id="por-que"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Se a declaração é gratuita, por que contratar?</p><h2 class="h2">Um erro no ITCMD custa mais do que a assessoria</h2></div>
    <p class="lede">A declaração é feita no sistema da Receita Estadual, mas o que vai nela define quanto você paga e se a escritura sai no prazo.</p>
  </div>
  <ul class="itc-base">
    <li class="rv"><h3>Valor dos bens</h3><p>Os imóveis não podem ser declarados abaixo da referência da prefeitura ou, nos rurais, da tabela do estado. Errar para menos gera <b>cobrança da diferença com multa e juros</b>; errar para mais é imposto pago à toa.</p></li>
    <li class="rv"><h3>Escritura parada</h3><p>Herdeiro ou bem faltando, fração errada ou documento vencido fazem a declaração voltar para correção. <b>Sem o imposto certo, o cartório não lavra a escritura.</b></p></li>
    <li class="rv"><h3>Isenção esquecida</h3><p>Algumas heranças são isentas, como, dentro de limites de valor, o imóvel usado como moradia. Mas <b>a isenção precisa ser pedida</b> na declaração: quem não pede, paga.</p></li>
  </ul>
  <p class="bento-nota rv"><b>Com a assessoria,</b> alguém confere tudo antes do envio e acompanha você até o registro e o IPTU, por valores a partir de R$&nbsp;347. <a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp style="color:var(--marsala);text-decoration:underline;text-underline-offset:3px">Peça o seu orçamento pelo WhatsApp</a></p>
</div></section>

<section class="sec itc" id="itcmd"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Entenda o ITCMD</p><h2 class="h2">O imposto da herança e da doação</h2></div>
    <p class="lede">Vai receber uma herança ou uma doação, ou está dividindo bens no divórcio? Então é provável que você precise declarar e pagar este imposto. Veja o básico.</p>
  </div>
  <ul class="itc-base">
    <li class="rv"><h3>O que é</h3><p><b>ITCMD</b> é o Imposto sobre Transmissão Causa Mortis e Doação. O estado o cobra quando um bem passa para outra pessoa <b>sem pagamento</b>: por herança ou por doação.</p><p>Também é chamado de ITCD, ITD ou, simplesmente, imposto da herança.</p></li>
    <li class="rv foco"><h3>Quanto é, no Paraná</h3><span class="itc-num">4%</span><p>do valor dos bens transmitidos, na herança e na doação (Lei estadual 18.573/2015, art. 22).</p><p>O valor é o de mercado na data da declaração e, nos imóveis, não pode ficar abaixo da referência da prefeitura ou, nos rurais, da tabela do estado. Exemplo: doação de um imóvel de R$&nbsp;500&nbsp;mil gera <b>R$&nbsp;20&nbsp;mil</b> de ITCMD.</p></li>
    <li class="rv"><h3>Quando pagar</h3><p>No cartório, <b>antes da assinatura da escritura</b>: inventário, doação ou divórcio. No inventário judicial, em até 30 dias depois da sentença que homologa a partilha.</p><p>Sem o imposto pago ou a isenção reconhecida pela Receita Estadual, a escritura não sai.</p></li>
  </ul>

  <h3 class="itc-sub rv">Em que situações ele aparece</h3>
  <ul class="itc-casos rv">
    <li><h4>Inventário</h4><p>Quando alguém falece e deixa bens, no cartório ou na Justiça. Vale também para a sobrepartilha de bens encontrados depois.</p></li>
    <li><h4>Doação</h4><p>De imóvel, dinheiro ou outros bens, inclusive de pais para filhos, como adiantamento de herança, com ou sem reserva de usufruto.</p></li>
    <li><h4>Divórcio, separação e fim da união estável</h4><p>Quando um recebe mais do que a sua metade sem pagar a diferença ao outro: a parte a mais é tratada como doação.</p></li>
    <li><h4>Extinção de usufruto</h4><p>Quando o usufruto termina, pelo falecimento ou pela renúncia de quem o tinha, e o dono passa a ter a propriedade completa.</p></li>
    <li><h4>Renúncia e cessão de herança</h4><p>A renúncia em favor de uma pessoa determinada e a cessão gratuita de direitos hereditários contam como nova transmissão.</p></li>
    <li><h4>Imóveis no Paraná</h4><p>O imposto é do Paraná mesmo que o falecido, o doador ou os herdeiros morem em outro estado.</p></li>
    <li><h4>Bens móveis</h4><p>Dinheiro, aplicações, veículos, quotas e ações: o imposto é do estado onde morava quem faleceu ou quem doou.</p></li>
    <li><h4>Isenções</h4><p>Algumas heranças não pagam, como, dentro de limites de valor, o imóvel urbano usado como moradia e o pequeno imóvel rural da família.</p></li>
  </ul>

  <p class="bento-nota rv"><b>ITCMD ou ITBI?</b> Se a transmissão tem pagamento, como na compra e venda, na permuta ou no divórcio em que um compensa o outro em dinheiro, o imposto é o ITBI, da prefeitura. Na dúvida, <a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp style="color:var(--marsala);text-decoration:underline;text-underline-offset:3px">pergunte pelo WhatsApp</a></p>
  <p class="micro rv">Regras do Paraná em vigor em novembro de 2026. A reforma tributária (Lei Complementar 227/2026) exige que os estados passem a cobrar alíquotas progressivas, então o percentual do Paraná pode mudar.</p>
</div></section>

<section class="sec" id="caminho" style="padding-top:0"><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">O caminho</p><h2 class="h2">Dos documentos ao IPTU, em 6 etapas</h2></div>
    <p class="lede">O que acontece em cada fase e onde a assessoria entra</p>
  </div>
  <ol class="bento">
    <li class="rv"><div><h3>Atualizar todos os documentos</h3><p>Reunir as certidões e os documentos pessoais e do imóvel, dentro da validade que o cartório exige</p></div></li>
    <li class="rv"><div><h3>Minuta da escritura</h3><p>O tabelionato prepara o texto da escritura pública; em inventários mais complexos, com muitos herdeiros, bens ou sucessões, costuma ser exigido também o formal de partilha, que deixa clara a linha sucessória e a fração de cada herdeiro</p></div></li>
    <li class="rv foco"><span class="pilula">Foco da assessoria</span><div><h3>Declaração do ITCMD</h3><p>Quando o imposto se aplica, a declaração é enviada online ao governo do estado, com base de cálculo e documentos conferidos</p></div></li>
    <li class="rv"><div><h3>Finalização da escritura</h3><p>Com o imposto pago, as partes assinam, presencialmente ou por videoconferência, e quitam as custas do tabelionato</p></div></li>
    <li class="rv"><div><h3>Registro do imóvel</h3><p>A escritura segue para o registro de imóveis, que lança a transmissão na matrícula. Há novas custas nesta fase</p></div></li>
    <li class="rv"><div><h3>Transferência do IPTU</h3><p>Com a matrícula atualizada, o cadastro na prefeitura passa para o nome de quem recebeu o imóvel</p></div></li>
  </ol>
  <p class="bento-nota rv"><b>Extinção de usufruto.</b> Aqui não há nova escritura: <a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp style="color:var(--marsala);text-decoration:underline;text-underline-offset:3px">tire sua dúvida pelo WhatsApp</a></p>
  <p class="bento-nota rv"><b>Imóvel rural.</b> Tem documentos e etapas próprios: <a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp style="color:var(--marsala);text-decoration:underline;text-underline-offset:3px">tire sua dúvida pelo WhatsApp</a></p>
</div></section>

<section class="sec" id="assessoria" style="padding-top:0"><div class="wrap duas">
  <div class="rv">
    <p class="kicker">A assessoria</p>
    <h2 class="h2">O que está incluído</h2>
    <p class="lede" style="margin-top:18px">Você envia os documentos; a assessoria confere, faz a declaração e explica o que vem depois</p>
    <ol class="lista">
      <li>Orientação sobre cada documento que o cartório pede</li>
      <li>Declaração do ITCMD em inventário (extrajudicial ou judicial), doação, sobrepartilha, divórcio e extinção de usufruto</li>
      <li>Explicação das fases seguintes: pagamento, assinatura, registro e IPTU</li>
      <li>Orientações sobre o imposto de renda pós-escritura: declaração do imóvel, ganho de capital, IPTU e o que entregar ao contador</li>
    </ol>
  </div>
  <aside class="cartao rv">
    <img src="<?php echo lo_t('img/maos-geracoes.webp'); ?>" alt="Mãos de quatro gerações de uma família, da mais idosa à de um bebê, lado a lado sobre uma mesa" width="900" height="600">
    <h3>Assessoria a partir de R$&nbsp;347</h3>
    <p>Conte o tipo de escritura e a cidade do imóvel. Respondemos em até 2 horas úteis, com o valor exato para o seu caso</p>
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  </aside>
</div></section>

<section class="sec" id="calculadora" style="padding-top:0" hidden><div class="wrap"><div class="escuro rv">
  <div>
    <p class="kicker">Calculadora gratuita</p>
    <h2 class="h2">Em breve: simule o ITCMD e as custas do seu caso</h2>
    <p class="lede">Estamos preparando uma calculadora para você estimar o imposto e as custas do cartório.</p>
  </div>
  <div class="em-breve">
    <p>Enquanto isso, conte o seu caso pelo WhatsApp: o tipo de escritura e a cidade do imóvel.</p>
    <a class="btn ouro" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  </div>
</div></div></section>

<section class="sec" id="artigos" style="padding-top:0" hidden><div class="wrap">
  <div class="intro rv">
    <div><p class="kicker">Artigos</p><h2 class="h2">Para ler com calma</h2></div>
  </div>
  <ul class="artigos">
    <li class="rv"><img src="<?php echo lo_t('img/artigo-assinatura.webp'); ?>" alt="Duas pessoas assinando documentos sobre uma mesa" width="640" height="427"><div class="txt"><h3>Inventário, doação, sobrepartilha e divórcio: o que muda em cada escritura</h3><span class="breve">Em breve</span></div></li>
    <li class="rv"><img src="<?php echo lo_t('img/artigo-araucaria.webp'); ?>" alt="Araucária recortada contra o pôr do sol" width="640" height="427"><div class="txt"><h3>Herdou um imóvel no Paraná? Os primeiros passos</h3><span class="breve">Em breve</span></div></li>
    <li class="rv"><img src="<?php echo lo_t('img/artigo-calculadora.webp'); ?>" alt="Miniatura de casa ao lado de uma calculadora e de uma caneta" width="640" height="427"><div class="txt"><h3>Vão aumentar o ITCMD no Paraná?</h3><span class="breve">Em breve</span></div></li>
    <li class="rv"><img src="<?php echo lo_t('img/artigo-caneta.webp'); ?>" alt="Caneta-tinteiro sobre uma folha escrita à mão" width="640" height="427"><div class="txt"><h3>Depois da escritura: o registro no cartório de imóveis</h3><span class="breve">Em breve</span></div></li>
  </ul>
</div></section>

<section class="sec" id="depoimentos" style="padding-top:0"><div class="wrap"><div class="depo rv">
  <p class="kicker">Depoimentos</p>
  <h2 class="h2">O que dizem os clientes</h2>
  <ul class="depo-trilho" id="depo-trilho" aria-label="Depoimentos de clientes">
    <li><figure><blockquote><p>Conseguimos <mark>resolver tudo rápido</mark> e minha filha assinou à distância.</p></blockquote><figcaption>Cliente, dona de casa · contratou a assessoria para uma escritura de inventário</figcaption></figure></li>
    <li><figure><blockquote><p>Você é <mark>a melhor</mark>! Muito obrigado pelos teus serviços.</p></blockquote><figcaption>Cliente, advogado · contratou a assessoria para uma escritura de permuta</figcaption></figure></li>
    <li><figure><blockquote><p>Parabéns… você é <mark>super diligente e competente</mark>. Vou precisar agendar uma outra missão.</p></blockquote><figcaption>Cliente, advogado · contratou a assessoria para uma escritura de cessão de direitos hereditários</figcaption></figure></li>
  </ul>
  <div class="depo-pontos" id="depo-pontos"></div>
  <p class="micro">Mensagens reais recebidas pelo WhatsApp. Os nomes foram omitidos para preservar a privacidade dos clientes.</p>
</div></div></section>

<section class="sec" id="perguntas" style="padding-top:0"><div class="wrap faq-grid">
  <div class="rv"><p class="kicker">Dúvidas frequentes</p><h2 class="h2">O que costumam nos perguntar</h2></div>
  <div class="perguntas rv">
    <details><summary>Se a declaração é gratuita, por que contratar?</summary><p>A assessoria existe para quem precisa transmitir um imóvel, mas não sabe por onde começar e quer ter a segurança de estar fazendo tudo certo, desde o imposto até o registro.</p></details>
    <details><summary>Inventário e escritura são coisas diferentes?</summary><p>No cartório, o inventário é formalizado por escritura pública, o mesmo instrumento usado na doação, na sobrepartilha, no divórcio e na nomeação de inventariante.</p></details>
    <details><summary>Em quais casos o ITCMD é devido?</summary><p>Na doação, na herança, na extinção de usufruto e no divórcio em que um dos cônjuges recebe mais do que a sua metade sem compensação, entre outras situações.</p></details>
    <details><summary>A ordem das etapas é sempre essa?</summary><p>É a sequência mais comum, mas cada tabelionato tem a sua rotina e pode inverter alguma fase.</p></details>
    <details><summary>Preciso ir presencialmente a algum lugar?</summary><p>A assessoria é toda à distância. A assinatura da escritura pode ser realizada pessoalmente ou por videoconferência, nos cartórios que trabalham com o sistema do e-Notariado.</p></details>
    <details><summary>Quanto custa?</summary><p>A assessoria começa em R$&nbsp;347. O valor final depende do número de envolvidos, da quantidade de bens e do que você precisa (caso ainda não tenha todos os documentos, por exemplo). Conte o seu caso pelo WhatsApp e receba o orçamento em até 2 horas úteis.</p></details>
  </div>
</div></section>

<section class="sec" id="legado" style="padding-top:0"><div class="wrap legado-par">
  <figure class="legado-foto rv"><img src="<?php echo lo_t('img/hero-casa-familia.webp'); ?>" alt="Miniaturas de madeira de uma casa e de uma família, ao lado de uma chave antiga" width="1280" height="640" loading="lazy"></figure>
  <div class="verbete-caixa rv">
      <div><p class="palavra">legado</p><p class="verbete">le·ga·do · <i>substantivo masculino</i></p></div>
      <ol class="sentidos">
        <li>Bem determinado que alguém deixa a outra pessoa em testamento</li>
        <li>Aquilo que uma geração transmite às seguintes: valores, histórias e patrimônio</li>
      </ol>
</div></div></section>

<section class="sec" style="padding-top:0;padding-bottom:clamp(24px,3vw,40px)"><div class="wrap"><div class="stage cta rv">
  <h2 class="h2">Escritura tem etapas. Vamos olhar cada uma.</h2>
  <p class="lede">Clique abaixo e veja por onde começar!</p>
  <div class="acoes">
    <a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a>
  </div>
</div></div></section>
</main>

<footer class="rodape"><div class="wrap">
  <div class="rod-topo quatro">
    <div>
      <a class="marca" href="#inicio" aria-label="Legado em Ordem, início"><img src="<?php echo lo_t('img/logo.webp'); ?>" alt="Legado em Ordem" width="480" height="187"></a>
      <p class="rod-txt">Assessoria para declaração de ITCMD<br>Atendimento à distância, em todo o Paraná</p>
    </div>
    <div><h4>Casos</h4><ul><li><a href="<?php echo lo_u('inventario/'); ?>">ITCMD no inventário</a></li><li><a href="<?php echo lo_u('doacao/'); ?>">ITCMD na doação</a></li><li><a href="<?php echo lo_u('doacao/#usufruto'); ?>">Extinção de usufruto</a></li><li><a href="<?php echo lo_u('divorcio/'); ?>">ITCMD no divórcio</a></li></ul></div>
    <div><h4>Navegação</h4><ul><li><a href="#itcmd">O que é o ITCMD</a></li><li><a href="#caminho">O caminho</a></li><li><a href="#assessoria">A assessoria</a></li><li><a href="#perguntas">Perguntas</a></li></ul></div>
    <div><h4>Contato</h4><ul><li><a href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></li><li><button type="button" class="linkbtn" data-politica>Política de privacidade</button></li></ul></div>
  </div>
  <div class="rod-base"><span>© 2026 Legado em Ordem</span><button type="button" class="linkbtn" data-politica>Política de privacidade</button></div>
  <p class="rod-legal">Legado em Ordem · CNPJ 48.747.993/0001-96 · Paranaguá-PR<br>Empresa privada, sem vínculo com a Receita Estadual ou outros órgãos públicos.</p>
</div></footer>

<div class="fixo"><a class="btn" href="https://wa.me/legado.em.ordem?text=Ol%C3%A1%21%20Vim%20pelo%20site%20Legado%20em%20Ordem%20e%20gostaria%20de%20um%20or%C3%A7amento%20para%20a%20declara%C3%A7%C3%A3o%20de%20ITCMD." target="_blank" rel="noopener" data-whatsapp>Falar pelo WhatsApp</a></div>

<dialog id="politica" aria-labelledby="pol-titulo"><div class="pol">
  <h2 id="pol-titulo">Política de privacidade</h2>
  <p>Como a Legado em Ordem trata os seus dados.</p>
  <h3>Responsável</h3><p>Legado em Ordem, CNPJ 48.747.993/0001-96, Paranaguá-PR.</p>
  <h3>Dados tratados</h3><p>As informações e os documentos que você nos envia ao entrar em contato pelo WhatsApp e dados de navegação coletados pela ferramenta de medição de anúncios do Google: com cookies, se você aceitá-los; sem cookies e sem identificar você, se você recusar ou não responder ao aviso (por exemplo, a página visitada e o clique no botão do WhatsApp).</p>
  <h3>Finalidade</h3><p>Responder ao seu contato, prestar o serviço contratado e medir o desempenho dos anúncios.</p>
  <h3>Base legal</h3><p>Procedimentos preliminares e execução de contrato (Lei 13.709/2018 (LGPD), art. 7º, V), para o atendimento e o serviço; consentimento (art. 7º, I), para os cookies de medição, que você pode recusar no aviso exibido no site; legítimo interesse (art. 7º, IX), para a medição sem cookies dos anúncios.</p>
  <h3>Compartilhamento</h3><p>Os dados não são vendidos nem cedidos para fins comerciais. Quando necessário ao serviço, são compartilhados com a Receita Estadual, o cartório e o registro de imóveis. A ferramenta de medição (Google) trata dados de navegação: com cookies, de quem os aceita; sem cookies, dos demais visitantes.</p>
  <h3>Prazo</h3><p>Os dados são mantidos pelo tempo necessário à finalidade ou ao cumprimento de obrigações legais.</p>
  <h3>Direitos do titular</h3>
  <ul><li>Confirmar se há tratamento e acessar os dados</li><li>Corrigir dados incompletos ou desatualizados</li><li>Pedir a exclusão dos dados, ressalvado o que a lei obriga a guardar</li><li>Revogar o consentimento dado aos cookies</li></ul>
  <p>Pedidos pelo WhatsApp <a href="https://wa.me/legado.em.ordem" target="_blank" rel="noopener">(41) 9 9153-1196</a>.</p>
  <p>Atualizada em 03/11/2026.</p>
  <form method="dialog"><button class="btn sec">Fechar</button></form>
</div></dialog>

<div class="cookies" id="cookies" role="dialog" aria-live="polite" aria-label="Aviso de cookies" hidden>
  <p>Usamos cookies para medir o desempenho dos nossos anúncios. Você pode aceitar ou recusar.</p>
  <div class="acoes-c">
    <button type="button" class="btn" data-cookies="aceito">Aceitar</button>
    <button type="button" class="btn sec" data-cookies="recusado">Recusar</button>
    <button type="button" class="linkbtn" data-politica>Política de privacidade</button>
  </div>
</div>



<script src="<?php echo lo_t('site.js'); ?>"></script>
<?php wp_footer(); ?>
</body>
</html>
